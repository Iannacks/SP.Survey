library(testthat)
library(SP.Survey)

test_check("SP.Survey")
