

dominant_alt<-function(condition,nb,sets,cand){
  library(choiceDes)
  alts<-2

  for (i in 1:4){
    if(condition[i]!="yes"&condition[i]!="no"&condition[i]!="NA"){
      stop("insert the right value(yes or no)")

    }}

temp_v<-rep(0,1000)

attempt<-sapply(1:(sets*nb),function(i)(alts*i+(-alts+1)))
if(condition[1]=="yes"&condition[2]=="NA"&condition[3]=="NA"&condition[4]=="NA"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}
if(condition[1]=="no"&condition[2]=="NA"&condition[3]=="NA"&condition[4]=="NA"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}
if(condition[1]=="yes"&condition[2]=="no"&condition[3]=="NA"&condition[4]=="NA"){
for (j in 1:1000){
  set.seed(j)
  design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
  temp<-0

  for (i in 1:(sets*nb)){
    if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
       as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
       as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])|
       as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
       as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
       as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])
       ){
      temp<-temp+1
      print(temp)
    }


  }
  temp_v[j]=temp



}
  zz<-which(temp_v==min(temp_v))
}

if(condition[1]=="no"&condition[2]=="yes"&condition[3]=="NA"&condition[4]=="NA"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])
         ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}

if(condition[1]=="no"&condition[2]=="no"&condition[3]=="NA"&condition[4]=="NA"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])
         ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}
if(condition[1]=="yes"&condition[2]=="yes"&condition[3]=="NA"&condition[4]=="NA"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}
if(condition[1]=="yes"&condition[2]=="yes"&condition[3]=="yes"&condition[4]=="NA"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}
if(condition[1]=="no"&condition[2]=="no"&condition[3]=="no"&condition[4]=="NA"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}
if(condition[1]=="yes"&condition[2]=="yes"&condition[3]=="no"&condition[4]=="NA"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}
if(condition[1]=="yes"&condition[2]=="no"&condition[3]=="yes"&condition[4]=="NA"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}
if(condition[1]=="yes"&condition[2]=="no"&condition[3]=="no"&condition[4]=="NA"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}
if(condition[1]=="no"&condition[2]=="yes"&condition[3]=="yes"&condition[4]=="NA"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}
if(condition[1]=="no"&condition[2]=="yes"&condition[3]=="no"&condition[4]=="NA"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}
if(condition[1]=="no"&condition[2]=="no"&condition[3]=="yes"&condition[4]=="NA"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}

if(condition[1]=="no"&condition[2]=="no"&condition[3]=="no"&condition[4]=="no"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}

if(condition[1]=="yes"&condition[2]=="yes"&condition[3]=="yes"&condition[4]=="yes"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}

if(condition[1]=="yes"&condition[2]=="yes"&condition[3]=="yes"&condition[4]=="no"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}

if(condition[1]=="yes"&condition[2]=="yes"&condition[3]=="no"&condition[4]=="yes"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}

if(condition[1]=="yes"&condition[2]=="yes"&condition[3]=="no"&condition[4]=="no"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}

if(condition[1]=="yes"&condition[2]=="no"&condition[3]=="yes"&condition[4]=="no"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}

if(condition[1]=="yes"&condition[2]=="no"&condition[3]=="no"&condition[4]=="yes"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}


if(condition[1]=="yes"&condition[2]=="no"&condition[3]=="no"&condition[4]=="no"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}
if(condition[1]=="yes"&condition[2]=="no"&condition[3]=="yes"&condition[4]=="yes"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}
if(condition[1]=="no"&condition[2]=="no"&condition[3]=="no"&condition[4]=="yes"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}


if(condition[1]=="no"&condition[2]=="no"&condition[3]=="yes"&condition[4]=="yes"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}

if(condition[1]=="no"&condition[2]=="yes"&condition[3]=="no"&condition[4]=="yes"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}

if(condition[1]=="no"&condition[2]=="yes"&condition[3]=="yes"&condition[4]=="no"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}

if(condition[1]=="no"&condition[2]=="yes"&condition[3]=="yes"&condition[4]=="yes"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}

if(condition[1]=="no"&condition[2]=="no"&condition[3]=="yes"&condition[4]=="no"){
  for (j in 1:1000){
    set.seed(j)
    design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)#step3
    temp<-0

    for (i in 1:(sets*nb)){
      if(as.numeric(design$levels[attempt[i]+1,4])>=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])<=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])>=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])>=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])<=as.numeric(design$levels[attempt[i],8])|
         as.numeric(design$levels[attempt[i]+1,4])<=as.numeric(design$levels[attempt[i],4])&
         as.numeric(design$levels[attempt[i]+1,5])>=as.numeric(design$levels[attempt[i],5])&
         as.numeric(design$levels[attempt[i]+1,6])<=as.numeric(design$levels[attempt[i],6])&
         as.numeric(design$levels[attempt[i]+1,7])<=as.numeric(design$levels[attempt[i],7])&
         as.numeric(design$levels[attempt[i]+1,8])>=as.numeric(design$levels[attempt[i],8])
      ){
        temp<-temp+1
        print(temp)
      }


    }
    temp_v[j]=temp



  }
  zz<-which(temp_v==min(temp_v))
}

set.seed(zz[1])
design <- dcm.design.cand(cand=cand, sets=sets, nb=nb, alts=alts)
q<-design$levels
lista<-list(dominant_alternative_founded=min(temp_v),seeds=zz,design=q)
return(lista)
}

