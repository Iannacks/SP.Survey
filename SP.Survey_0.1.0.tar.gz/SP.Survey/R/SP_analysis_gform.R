SP_econometric_analysis<-function(dataset_forms, sets,nalts,nblocks,nrespondents,design,type_variable){
  library(readxl)
  library(varhandle)
  library(mlogit)
  if(nblocks==1){
    resp<-read_excel(dataset_forms[1])#step1
    resp<-as.vector(t(resp[,2:(sets+1)]))
    resp<-to.dummy(resp,"resp")
    resp<-as.vector(t(resp))
    dataset1<-do.call(rbind, replicate(nrespondents[1],design[1:(sets*nalts),], simplify=FALSE))
    dataset1$ALT<-rep(c(nalts-1,nalts),sets*nrespondents[1])
    dataset1<-cbind(dataset1,resp)
    mlogit_dataset<-mlogit.data(dataset1, shape="long",choice="resp",alt.var="ALT")
    if(type_variable[1]=="quantitative"){
      mlogit_dataset$x1<-as.numeric(mlogit_dataset$x1)
    }
    if(type_variable[2]=="quantitative"){
      mlogit_dataset$x2<-as.numeric(mlogit_dataset$x2)
    }
    if(type_variable[3]=="quantitative"){
      mlogit_dataset$x3<-as.numeric(mlogit_dataset$x3)
    }
    if(type_variable[4]=="quantitative"){
      mlogit_dataset$x4<-as.numeric(mlogit_dataset$x4)
    }
    if(type_variable[5]=="quantitative"){
      mlogit_dataset$x5<-as.numeric(mlogit_dataset$x5)
    }
    if(type_variable[6]=="quantitative"){
      mlogit_dataset$x6<-as.numeric(mlogit_dataset$x6)
    }
    if(length(design[1,])-3==1){
      expr<-resp~x1
    }
    if(length(design[1,])-3==2){
      expr<-resp~x1+x2
    }
    if(length(design[1,])-3==3){
      expr<-resp~x1+x2+x3
      print(expr)
    }
    if(length(design[1,])-3==4){
      expr<-resp~x1+x2+x3+x4
    }
    if(length(design[1,])-3==5){
      expr<-resp~x1+x2+x3+x4+x5
    }
    if(length(design[1,])-3==6){
      expr<-resp~x1+x2+x3+x4+x6
    }
    model<-mlogit(expr,data=mlogit_dataset)
    summary(model)
  }
  if(nblocks==2){

    resp1<-read_excel(dataset_forms[1])#step1
    resp1<-as.vector(t(resp1[,2:(sets+1)]))
    resp1<-to.dummy(resp1,"resp")
    resp1<-as.vector(t(resp1))
    resp2<-read_excel(dataset_forms[2])#step1
    resp2<-as.vector(t(resp2[,2:(sets+1)]))
    resp2<-to.dummy(resp2,"resp")
    resp2<-as.vector(t(resp2))
    resp<-append(resp1,resp2)
    dataset1<-do.call(rbind, replicate(nrespondents[1],design[1:(sets*nalts),], simplify=FALSE))
    dataset2<-do.call(rbind, replicate(nrespondents[2],design[((sets*nalts)+1):(sets*nalts*nblocks),], simplify=FALSE))
    dataset<-rbind(dataset1,dataset2)
    #link resp to the dataset
    dataset<-cbind(dataset,resp)
    dataset$ALT<-rep(c(nalts-1,nalts),sets*(nrespondents[1]+nrespondents[2]))
    mlogit_dataset<-mlogit.data(dataset, shape="long",choice="resp",alt.var="ALT")
    if(type_variable[1]=="quantitative"){
      mlogit_dataset$x1<-as.numeric(mlogit_dataset$x1)
    }
    if(type_variable[2]=="quantitative"){
      mlogit_dataset$x2<-as.numeric(mlogit_dataset$x2)
    }
    if(type_variable[3]=="quantitative"){
      mlogit_dataset$x3<-as.numeric(mlogit_dataset$x3)
    }
    if(type_variable[4]=="quantitative"){
      mlogit_dataset$x4<-as.numeric(mlogit_dataset$x4)
    }
    if(type_variable[5]=="quantitative"){
      mlogit_dataset$x5<-as.numeric(mlogit_dataset$x5)
    }
    if(type_variable[6]=="quantitative"){
      mlogit_dataset$x6<-as.numeric(mlogit_dataset$x6)
    }
    if(length(design[1,])-3==1){
      expr<-resp~x1
    }
    if(length(design[1,])-3==2){
      expr<-resp~x1+x2
    }
    if(length(design[1,])-3==3){
      expr<-resp~x1+x2+x3
      print(expr)
    }
    if(length(design[1,])-3==4){
      expr<-resp~x1+x2+x3+x4
    }
    if(length(design[1,])-3==5){
      expr<-resp~x1+x2+x3+x4+x5
    }
    if(length(design[1,])-3==6){
      expr<-resp~x1+x2+x3+x4+x6
    }
    model<-mlogit(expr,data=mlogit_dataset)
    summary(model)
  }


  if(nblocks==3){
    resp1<-read_excel(dataset_forms[1])#step1
    resp1<-as.vector(t(resp1[,2:(sets+1)]))
    resp1<-to.dummy(resp1,"resp")
    resp1<-as.vector(t(resp1))
    resp2<-read_excel(dataset_forms[2])#step1
    resp2<-as.vector(t(resp2[,2:(sets+1)]))
    resp2<-to.dummy(resp2,"resp")
    resp2<-as.vector(t(resp2))
    resp3<-read_excel(dataset_forms[3])#step1
    resp3<-as.vector(t(resp3[,2:(sets+1)]))
    resp3<-to.dummy(resp3,"resp")
    resp3<-as.vector(t(resp3))
    resp<-append(resp1,resp2,resp3)
    dataset1<-do.call(rbind, replicate(nrespondents[1],design[1:(sets*nalts),], simplify=FALSE))
    dataset2<-do.call(rbind, replicate(nrespondents[2],design[((sets*nalts)+1):(sets*nalts*(nblocks-1)),], simplify=FALSE))
    dataset3<-do.call(rbind, replicate(nrespondents[3],design[((sets*nalts*(nblocks-1))+1):(sets*nalts*nblocks),], simplify=FALSE))
    dataset<-rbind(dataset1,dataset2,dataset3)
    #link resp to the dataset
    dataset<-cbind(dataset,resp)
    dataset$ALT<-rep(c(nalts-1,nalts),sets*(nrespondents[1]+nrespondents[2]+nrespondents[3]))
    mlogit_dataset<-mlogit.data(dataset, shape="long",choice="resp",alt.var="ALT")
    if(type_variable[1]=="quantitative"){
      mlogit_dataset$x1<-as.numeric(mlogit_dataset$x1)
    }
    if(type_variable[2]=="quantitative"){
      mlogit_dataset$x2<-as.numeric(mlogit_dataset$x2)
    }
    if(type_variable[3]=="quantitative"){
      mlogit_dataset$x3<-as.numeric(mlogit_dataset$x3)
    }
    if(type_variable[4]=="quantitative"){
      mlogit_dataset$x4<-as.numeric(mlogit_dataset$x4)
    }
    if(type_variable[5]=="quantitative"){
      mlogit_dataset$x5<-as.numeric(mlogit_dataset$x5)
    }
    if(type_variable[6]=="quantitative"){
      mlogit_dataset$x6<-as.numeric(mlogit_dataset$x6)
    }
    if(length(design[1,])-3==1){
      expr<-resp~x1
    }
    if(length(design[1,])-3==2){
      expr<-resp~x1+x2
    }
    if(length(design[1,])-3==3){
      expr<-resp~x1+x2+x3
      print(expr)
    }
    if(length(design[1,])-3==4){
      expr<-resp~x1+x2+x3+x4
    }
    if(length(design[1,])-3==5){
      expr<-resp~x1+x2+x3+x4+x5
    }
    if(length(design[1,])-3==6){
      expr<-resp~x1+x2+x3+x4+x6
    }
    model<-mlogit(expr,data=mlogit_dataset)
    summary(model)
  }
  if(nblocks==4){
    resp1<-read_excel(dataset_forms[1])#step1
    resp1<-as.vector(t(resp1[,2:(sets+1)]))
    resp1<-to.dummy(resp1,"resp")
    resp1<-as.vector(t(resp1))
    resp2<-read_excel(dataset_forms[2])#step1
    resp2<-as.vector(t(resp2[,2:(sets+1)]))
    resp2<-to.dummy(resp2,"resp")
    resp2<-as.vector(t(resp2))
    resp3<-read_excel(dataset_forms[3])#step1
    resp3<-as.vector(t(resp3[,2:(sets+1)]))
    resp3<-to.dummy(resp3,"resp")
    resp3<-as.vector(t(resp3))############
    resp4<-read_excel(dataset_forms[4])#step1
    resp4<-as.vector(t(resp4[,2:(sets+1)]))
    resp4<-to.dummy(resp4,"resp")
    resp4<-as.vector(t(resp4))
    resp<-append(resp1,resp2,resp3,resp4)
    dataset1<-do.call(rbind, replicate(nrespondents[1],design[1:(sets*nalts),], simplify=FALSE))
    dataset2<-do.call(rbind, replicate(nrespondents[2],design[((sets*nalts)+1):(sets*nalts*(nblocks-2)),], simplify=FALSE))
    dataset3<-do.call(rbind, replicate(nrespondents[3],design[((sets*nalts*(nblocks-2))+1):(sets*nalts*(nblocks-1)),], simplify=FALSE))
    dataset4<-do.call(rbind, replicate(nrespondents[4],design[((sets*nalts*(nblocks-1))+1):(sets*nalts*nblocks),], simplify=FALSE))
    dataset<-rbind(dataset1,dataset2,dataset3,dataset4)
    #link resp to the dataset
    dataset<-cbind(dataset,resp)
    dataset$ALT<-rep(c(nalts-1,nalts),sets*(nrespondents[1]+nrespondents[2]+nrespondents[3]+nrespondents[4]))
    mlogit_dataset<-mlogit.data(dataset, shape="long",choice="resp",alt.var="ALT")
    if(type_variable[1]=="quantitative"){
      mlogit_dataset$x1<-as.numeric(mlogit_dataset$x1)
    }
    if(type_variable[2]=="quantitative"){
      mlogit_dataset$x2<-as.numeric(mlogit_dataset$x2)
    }
    if(type_variable[3]=="quantitative"){
      mlogit_dataset$x3<-as.numeric(mlogit_dataset$x3)
    }
    if(type_variable[4]=="quantitative"){
      mlogit_dataset$x4<-as.numeric(mlogit_dataset$x4)
    }
    if(type_variable[5]=="quantitative"){
      mlogit_dataset$x5<-as.numeric(mlogit_dataset$x5)
    }
    if(type_variable[6]=="quantitative"){
      mlogit_dataset$x6<-as.numeric(mlogit_dataset$x6)
    }
    if(length(design[1,])-3==1){
      expr<-resp~x1
    }
    if(length(design[1,])-3==2){
      expr<-resp~x1+x2
    }
    if(length(design[1,])-3==3){
      expr<-resp~x1+x2+x3
      print(expr)
    }
    if(length(design[1,])-3==4){
      expr<-resp~x1+x2+x3+x4
    }
    if(length(design[1,])-3==5){
      expr<-resp~x1+x2+x3+x4+x5
    }
    if(length(design[1,])-3==6){
      expr<-resp~x1+x2+x3+x4+x6
    }
    model<-mlogit(expr,data=mlogit_dataset)
    summary(model)
  }

  if(nblocks==5){
    resp1<-read_excel(dataset_forms[1])#step1
    resp1<-as.vector(t(resp1[,2:(sets+1)]))
    resp1<-to.dummy(resp1,"resp")
    resp1<-as.vector(t(resp1))
    resp2<-read_excel(dataset_forms[2])#step1
    resp2<-as.vector(t(resp2[,2:(sets+1)]))
    resp2<-to.dummy(resp2,"resp")
    resp2<-as.vector(t(resp2))
    resp3<-read_excel(dataset_forms[3])#step1
    resp3<-as.vector(t(resp3[,2:(sets+1)]))
    resp3<-to.dummy(resp3,"resp")
    resp3<-as.vector(t(resp3))############
    resp4<-read_excel(dataset_forms[4])#step1
    resp4<-as.vector(t(resp4[,2:(sets+1)]))
    resp4<-to.dummy(resp4,"resp")
    resp4<-as.vector(t(resp4))###########
    resp5<-read_excel(dataset_forms[5])#step1
    resp5<-as.vector(t(resp5[,2:(sets+1)]))
    resp5<-to.dummy(resp5,"resp")
    resp5<-as.vector(t(resp5))
    resp<-append(resp1,resp2,resp3,resp4,resp5)
    dataset1<-do.call(rbind, replicate(nrespondents[1],design[1:(sets*nalts),], simplify=FALSE))
    dataset2<-do.call(rbind, replicate(nrespondents[2],design[((sets*nalts)+1):(sets*nalts*(nblocks-3)),], simplify=FALSE))
    dataset3<-do.call(rbind, replicate(nrespondents[3],design[((sets*nalts*(nblocks-3))+1):(sets*nalts*(nblocks-2)),], simplify=FALSE))
    dataset4<-do.call(rbind, replicate(nrespondents[4],design[((sets*nalts*(nblocks-2))+1):(sets*nalts*(nblocks-1)),], simplify=FALSE))
    dataset5<-do.call(rbind, replicate(nrespondents[5],design[((sets*nalts*(nblocks-1))+1):(sets*nalts*nblocks),], simplify=FALSE))
    dataset<-rbind(dataset1,dataset2,dataset3,dataset4,dataset5)
    #link resp to the dataset
    dataset$ALT<-rep(c(nalts-1,nalts),sets*(nrespondents[1]+nrespondents[2]+nrespondents[3]+nrespondents[4]+nrespondents[5]))
    dataset<-cbind(dataset,dataset$ALT,resp)
    mlogit_dataset<-mlogit.data(dataset, shape="long",choice="resp",alt.var="ALT")
    if(type_variable[1]=="quantitative"){
      mlogit_dataset$x1<-as.numeric(mlogit_dataset$x1)
    }
    if(type_variable[2]=="quantitative"){
      mlogit_dataset$x2<-as.numeric(mlogit_dataset$x2)
    }
    if(type_variable[3]=="quantitative"){
      mlogit_dataset$x3<-as.numeric(mlogit_dataset$x3)
    }
    if(type_variable[4]=="quantitative"){
      mlogit_dataset$x4<-as.numeric(mlogit_dataset$x4)
    }
    if(type_variable[5]=="quantitative"){
      mlogit_dataset$x5<-as.numeric(mlogit_dataset$x5)
    }
    if(type_variable[6]=="quantitative"){
      mlogit_dataset$x6<-as.numeric(mlogit_dataset$x6)
    }
    if(length(design[1,])-3==1){
      expr<-resp~x1
    }
    if(length(design[1,])-3==2){
      expr<-resp~x1+x2
    }
    if(length(design[1,])-3==3){
      expr<-resp~x1+x2+x3
      print(expr)
    }
    if(length(design[1,])-3==4){
      expr<-resp~x1+x2+x3+x4
    }
    if(length(design[1,])-3==5){
      expr<-resp~x1+x2+x3+x4+x5
    }
    if(length(design[1,])-3==6){
      expr<-resp~x1+x2+x3+x4+x6
    }
    model<-mlogit(expr,data=mlogit_dataset)
    summary(model)
  }

  if(nblocks==6){
    resp1<-read_excel(dataset_forms[1])#step1
    resp1<-as.vector(t(resp1[,2:(sets+1)]))
    resp1<-to.dummy(resp1,"resp")
    resp1<-as.vector(t(resp1))
    resp2<-read_excel(dataset_forms[2])#step1
    resp2<-as.vector(t(resp2[,2:(sets+1)]))
    resp2<-to.dummy(resp2,"resp")
    resp2<-as.vector(t(resp2))
    resp3<-read_excel(dataset_forms[3])#step1
    resp3<-as.vector(t(resp3[,2:(sets+1)]))
    resp3<-to.dummy(resp3,"resp")
    resp3<-as.vector(t(resp3))############
    resp4<-read_excel(dataset_forms[4])#step1
    resp4<-as.vector(t(resp4[,2:(sets+1)]))
    resp4<-to.dummy(resp4,"resp")
    resp4<-as.vector(t(resp4))###########
    resp5<-read_excel(dataset_forms[5])#step1
    resp5<-as.vector(t(resp5[,2:(sets+1)]))
    resp5<-to.dummy(resp5,"resp")
    resp5<-as.vector(t(resp5))###########
    resp6<-read_excel(dataset_forms[6])#step1
    resp6<-as.vector(t(resp6[,2:(sets+1)]))
    resp6<-to.dummy(resp6,"resp")
    resp6<-as.vector(t(resp6))
    resp<-append(resp1,resp2,resp3,resp4,resp5,resp6)
    dataset1<-do.call(rbind, replicate(nrespondents[1],design[1:(sets*nalts),], simplify=FALSE))
    dataset2<-do.call(rbind, replicate(nrespondents[2],design[((sets*nalts)+1):(sets*nalts*(nblocks-4)),], simplify=FALSE))
    dataset3<-do.call(rbind, replicate(nrespondents[3],design[((sets*nalts*(nblocks-4))+1):(sets*nalts*(nblocks-3)),], simplify=FALSE))
    dataset4<-do.call(rbind, replicate(nrespondents[4],design[((sets*nalts*(nblocks-3))+1):(sets*nalts*(nblocks-2)),], simplify=FALSE))
    dataset5<-do.call(rbind, replicate(nrespondents[5],design[((sets*nalts*(nblocks-2))+1):(sets*nalts*(nblocks-1)),], simplify=FALSE))
    dataset6<-do.call(rbind, replicate(nrespondents[6],design[((sets*nalts*(nblocks-1))+1):(sets*nalts*nblocks),], simplify=FALSE))
    dataset<-rbind(dataset1,dataset2,dataset3,dataset4,dataset5,dataset6)
    #link resp to the dataset
    dataset$ALT<-rep(c(nalts-1,nalts),sets*(nrespondents[1]+nrespondents[2]+nrespondents[3]+nrespondents[4]+nrespondents[5]))
    dataset<-cbind(dataset,dataset$ALT)
    mlogit_dataset<-mlogit.data(dataset, shape="long",choice="resp",alt.var="ALT")

    if(type_variable[1]=="quantitative"){
      mlogit_dataset$x1<-as.numeric(mlogit_dataset$x1)
    }
    if(type_variable[2]=="quantitative"){
      mlogit_dataset$x2<-as.numeric(mlogit_dataset$x2)
    }
    if(type_variable[3]=="quantitative"){
      mlogit_dataset$x3<-as.numeric(mlogit_dataset$x3)
    }
    if(type_variable[4]=="quantitative"){
      mlogit_dataset$x4<-as.numeric(mlogit_dataset$x4)
    }
    if(type_variable[5]=="quantitative"){
      mlogit_dataset$x5<-as.numeric(mlogit_dataset$x5)
    }
    if(type_variable[6]=="quantitative"){
      mlogit_dataset$x6<-as.numeric(mlogit_dataset$x6)
    }
    if(length(design[1,])-3==1){
      expr<-resp~x1
    }
    if(length(design[1,])-3==2){
      expr<-resp~x1+x2
    }
    if(length(design[1,])-3==3){
      expr<-resp~x1+x2+x3
      print(expr)
    }
    if(length(design[1,])-3==4){
      expr<-resp~x1+x2+x3+x4
    }
    if(length(design[1,])-3==5){
      expr<-resp~x1+x2+x3+x4+x5
    }
    if(length(design[1,])-3==6){
      expr<-resp~x1+x2+x3+x4+x6
    }
    model<-mlogit(expr,data=mlogit_dataset)
    summary(model)
  }
  q<-summary(model)
  p<-list(q,mlogit_dataset)
  return(p)

}
